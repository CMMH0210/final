package com2.simplilearn2022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Simplilearn2022ApplicationTests {

	@Test
	void contextLoads() {
	}

}
